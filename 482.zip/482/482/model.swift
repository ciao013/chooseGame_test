//
//  model.swift
//  482
//
//  Created by partTimeWorker on 15/4/2022.
//

import Foundation
    struct Question{
        var questions:String
        var option:[String]
        var answer:String
    }
    var QuestionNumber = 0;
    var question1=[
            Question(questions:" ",option: ["123", "456", "586ccc"], answer: "586ccc" ),
            Question(questions:" ",option: ["123ccc", "111", "222"], answer: "123ccc" ),
            Question(questions:" ",option: ["tttt", "tesst", "test"], answer: "test" ),
            Question(questions:"number",option: ["1", "g", "ap"], answer: "1" ),
            Question(questions:"g",option: ["g", "111", "222"], answer: "g" ),
            Question(questions:" ",option: ["ghost", "dooo", "fig"], answer: "ghost" ),
            Question(questions:"c",option: ["ji", "cj", "c"], answer: "c" ),
            Question(questions:" ",option: ["tah", "teah", "teach"], answer: "teach" ),
            Question(questions:" ",option: ["1", "123", "123"], answer: "1" ),
            Question(questions:" ",option: ["4", "4", "0"], answer: "0" ),
            Question(questions:" ",option: ["123ccc", "111", "222"], answer: "123ccc" ),
            Question(questions:" ",option: ["tttt", "tesst", "test"], answer: "test" ),
            Question(questions:"number",option: ["1", "g", "ap"], answer: "1" ),
            Question(questions:"g",option: ["g", "111", "222"], answer: "g" ),
            Question(questions:" ",option: ["ghost", "dooo", "fig"], answer: "ghost" ),
            Question(questions:"c",option: ["ji", "cj", "c"], answer: "c" ),
            Question(questions:" ",option: ["tah", "teah", "teach"], answer: "teach" ),
            Question(questions:" ",option: ["1", "123", "123"], answer: "1" ),
            Question(questions:" ",option: ["4", "4", "0"], answer: "0" )
    ]
  /*  class QuestionsValues{
        var questions:[Question]?
        var option:[String]?
        var answer:String = ""
    }*/

